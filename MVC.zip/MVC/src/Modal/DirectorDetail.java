package Modal;

public class DirectorDetail {
	
	private String primaryName;

	public DirectorDetail(String primaryName) {
		super();
		this.primaryName = primaryName;
	}

	public String getPrimaryName() {
		return primaryName;
	}

	public void setPrimaryName(String primaryName) {
		this.primaryName = primaryName;
	}
}
